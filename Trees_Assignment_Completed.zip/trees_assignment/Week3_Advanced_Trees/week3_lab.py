"""Week 3 Lab - Advanced Trees. Recreated from the supplied handout's Appendix A."""
import bisect, random, time, json, csv, os, sys
sys.setrecursionlimit(20000)

class BSTNode:
    def __init__(self, key): self.key, self.left, self.right = key, None, None
class BST:
    def __init__(self): self.root = None
    def insert(self, key):
        if self.root is None: self.root = BSTNode(key); return
        cur = self.root
        while True:
            if key == cur.key: return
            if key < cur.key:
                if cur.left is None: cur.left = BSTNode(key); return
                cur = cur.left
            else:
                if cur.right is None: cur.right = BSTNode(key); return
                cur = cur.right
    def search(self, key):
        cur = self.root
        while cur:
            if key == cur.key: return True
            cur = cur.left if key < cur.key else cur.right
        return False
    def height(self):
        if self.root is None: return -1
        stack=[(self.root,0)]; ans=0
        while stack:
            n,d=stack.pop(); ans=max(ans,d)
            if n.left: stack.append((n.left,d+1))
            if n.right: stack.append((n.right,d+1))
        return ans

def rotate_left(x):
    if x is None or x.right is None: return x
    y=x.right; x.right=y.left; y.left=x; return y
def rotate_right(y):
    if y is None or y.left is None: return y
    x=y.left; y.left=x.right; x.right=y; return x

class AVLNode:
    def __init__(self,key): self.key,self.left,self.right,self.height=key,None,None,0
def h(node): return node.height if node else -1
def update(node): node.height=1+max(h(node.left),h(node.right))
def balance(node): return h(node.left)-h(node.right)
class AVLTree:
    def __init__(self): self.root=None; self.rotations=0
    def rotate_left(self,x):
        y=x.right; x.right=y.left; y.left=x; update(x); update(y); self.rotations+=1; return y
    def rotate_right(self,y):
        x=y.left; y.left=x.right; x.right=y; update(y); update(x); self.rotations+=1; return x
    def rebalance(self,node):
        update(node); bf=balance(node)
        if bf>1:
            if balance(node.left)<0: node.left=self.rotate_left(node.left)
            return self.rotate_right(node)
        if bf < -1:
            if balance(node.right)>0: node.right=self.rotate_right(node.right)
            return self.rotate_left(node)
        return node
    def insert(self,key): self.root=self._insert(self.root,key)
    def _insert(self,node,key):
        if node is None: return AVLNode(key)
        if key<node.key: node.left=self._insert(node.left,key)
        elif key>node.key: node.right=self._insert(node.right,key)
        else: return node
        return self.rebalance(node)
    def search(self,key):
        cur=self.root
        while cur:
            if cur.key==key:return True
            cur=cur.left if key<cur.key else cur.right
        return False
    def height(self): return h(self.root)
    def is_valid(self):
        def check(n,lo,hi):
            if n is None:return -1
            assert (lo is None or lo<n.key) and (hi is None or n.key<hi), f"BST order at {n.key}"
            lh=check(n.left,lo,n.key); rh=check(n.right,n.key,hi)
            assert n.height==1+max(lh,rh),f"stored height at {n.key}"
            assert abs(lh-rh)<=1,f"balance factor at {n.key}"
            return n.height
        check(self.root,None,None); return True

def is_valid_rb(t):
    """Validate nested (key, 'R'/'B', left, right); NIL None contributes black-height 1."""
    try:
        if t is None: return (True,1)
        if t[1] not in ('R','B'): raise ValueError(f"invalid colour at {t[0]}")
        if t[1] != 'B': raise ValueError(f"root {t[0]} is not black")
        def check(n,lo,hi):
            if n is None:return 1
            key,c,left,right=n
            if c not in ('R','B'): raise ValueError(f"invalid colour at {key}")
            if lo is not None and key<=lo or hi is not None and key>=hi: raise ValueError(f"BST order at {key}")
            if c=='R':
                if left is not None and left[1]=='R': raise ValueError(f"red-red at {key}")
                if right is not None and right[1]=='R': raise ValueError(f"red-red at {key}")
            a=check(left,lo,key); b=check(right,key,hi)
            if a!=b: raise ValueError(f"black-height mismatch at {key}: {a} vs {b}")
            return a+(1 if c=='B' else 0)
        return (True,check(t,None,None))
    except (ValueError, IndexError, TypeError) as e: return (False,str(e))

# Red-Black tree used in the benchmark, CLRS insertion and NIL sentinel.
class RBNode:
    def __init__(self,key,color,nil): self.key,self.color,self.left,self.right,self.parent=key,color,nil,nil,nil
class RBTree:
    def __init__(self):
        self.nil=RBNode(None,'B',None); self.nil.left=self.nil.right=self.nil.parent=self.nil; self.root=self.nil
    def rotate_left(self,x):
        y=x.right; x.right=y.left
        if y.left is not self.nil:y.left.parent=x
        y.parent=x.parent
        if x.parent is self.nil:self.root=y
        elif x is x.parent.left:x.parent.left=y
        else:x.parent.right=y
        y.left=x; x.parent=y
    def rotate_right(self,y):
        x=y.left; y.left=x.right
        if x.right is not self.nil:x.right.parent=y
        x.parent=y.parent
        if y.parent is self.nil:self.root=x
        elif y is y.parent.right:y.parent.right=x
        else:y.parent.left=x
        x.right=y; y.parent=x
    def insert(self,key):
        z=RBNode(key,'R',self.nil); y=self.nil; x=self.root
        while x is not self.nil:
            y=x
            if key==x.key:return
            x=x.left if key<x.key else x.right
        z.parent=y
        if y is self.nil:self.root=z
        elif key<y.key:y.left=z
        else:y.right=z
        self._fix_insert(z)
    def _fix_insert(self,z):
        while z.parent.color=='R':
            if z.parent is z.parent.parent.left:
                y=z.parent.parent.right
                if y.color=='R':
                    z.parent.color='B'; y.color='B'; z.parent.parent.color='R'; z=z.parent.parent
                else:
                    if z is z.parent.right:z=z.parent; self.rotate_left(z)
                    z.parent.color='B'; z.parent.parent.color='R'; self.rotate_right(z.parent.parent)
            else:
                y=z.parent.parent.left
                if y.color=='R':
                    z.parent.color='B'; y.color='B'; z.parent.parent.color='R'; z=z.parent.parent
                else:
                    if z is z.parent.left:z=z.parent; self.rotate_right(z)
                    z.parent.color='B'; z.parent.parent.color='R'; self.rotate_left(z.parent.parent)
        self.root.color='B'; self.root.parent=self.nil
    def search(self,key):
        x=self.root
        while x is not self.nil:
            if key==x.key:return True
            x=x.left if key<x.key else x.right
        return False
    def height(self):
        if self.root is self.nil:return -1
        stack=[(self.root,0)]; ans=0
        while stack:
            n,d=stack.pop(); ans=max(ans,d)
            if n.left is not self.nil:stack.append((n.left,d+1))
            if n.right is not self.nil:stack.append((n.right,d+1))
        return ans
    def is_valid(self):
        def go(n,lo,hi):
            if n is self.nil:return 1
            assert lo is None or lo<n.key; assert hi is None or n.key<hi
            if n.color=='R': assert n.left.color=='B' and n.right.color=='B'
            a=go(n.left,lo,n.key); b=go(n.right,n.key,hi); assert a==b
            return a+(n.color=='B')
        assert self.root.color=='B'; go(self.root,None,None); return True

class SortedList:
    def __init__(self): self.items=[]
    def insert(self,k): bisect.insort(self.items,k)
    def search(self,k): i=bisect.bisect_left(self.items,k); return i<len(self.items) and self.items[i]==k
    def height(self): return -1

def run_benchmarks(output_dir='.'):
    rng=random.Random(2026); rows=[]
    for n in (1000,2000,4000,8000):
      for order in ('random','sorted'):
        keys=list(range(n))
        if order=='random':rng.shuffle(keys)
        probe=rng.sample(keys,min(1000,len(keys)))
        for name,cls in [('BST',BST),('AVL',AVLTree),('Red-Black',RBTree),('Sorted list',SortedList)]:
          obj=cls(); t0=time.perf_counter()
          for k in keys:obj.insert(k)
          insert_ms=(time.perf_counter()-t0)*1000
          t0=time.perf_counter()
          for k in probe:obj.search(k)
          search_ms=(time.perf_counter()-t0)*1000
          height=obj.height()
          if name=='AVL': obj.is_valid()
          if name=='Red-Black': obj.is_valid()
          rows.append({'n':n,'order':order,'structure':name,'insert_ms':round(insert_ms,3),'search_ms_1000':round(search_ms,3),'height':height})
    with open(os.path.join(output_dir,'week3_benchmark.csv'),'w',newline='') as f:
      w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    return rows

def run_tests():
    t=BST()
    for k in range(2000):t.insert(k)
    assert t.height()==1999 and t.search(1234) and not t.search(5000)
    rng=random.Random(0)
    for _ in range(100):
      x=BST()
      for k in rng.sample(range(500),40):x.insert(k)
      def ino(n):return ino(n.left)+[n.key]+ino(n.right) if n else []
      before=ino(x.root); x.root=rotate_left(x.root) if x.root.right else rotate_right(x.root); assert ino(x.root)==before
    for order in ('sorted','random'):
      keys=list(range(3000));
      if order=='random':random.Random(1).shuffle(keys)
      a=AVLTree()
      for k in keys:a.insert(k)
      assert a.is_valid() and a.height()<=18
    good=(13,'B',(8,'R',(1,'B',None,None),(11,'B',None,None)),(17,'R',(15,'B',None,None),(25,'B',None,None)))
    bad=(20,'B',(10,'B',None,None),(30,'B',(25,'R',None,(27,'R',None,None)),None))
    assert is_valid_rb(good)==(True,3) and is_valid_rb(bad)[0] is False
    rb=RBTree(); keys=list(range(1000)); random.Random(3).shuffle(keys)
    for k in keys:rb.insert(k)
    assert rb.is_valid() and all(rb.search(k) for k in range(1000))
    print('PASS BST insert/search/iterative height')
    print('PASS rotations preserve in-order traversal')
    print('PASS AVL insert, heights, balance validator')
    print('PASS Red-Black validator and benchmark tree')
if __name__=='__main__':
    run_tests()
