# Week 3 — Lab 3: Advanced Trees
**Name:** Aziz Giyosov  
**Student ID:** 4251456  
**Date:** 10 October 2026

## Part A — BST degeneration

| n | Sorted BST height | Random BST height (this reproducible run) | ceil(log₂ n) |
|---:|---:|---:|---:|
| 100 | 99 | 11 | 7 |
| 500 | 499 | 19 | 9 |
| 1,000 | 999 | 24 | 10 |
| 2,000 | 1,999 | 26 | 11 |
| 5,000 | 4,999 | 29 | 13 |

The random heights are one run with a fixed seed; other random orders can produce different heights. Sorted input creates a chain of height n−1.

**A5.** Recursive insertion on sorted keys repeatedly calls itself down the chain. With Python's default recursion limit (normally 1,000), it raises `RecursionError` at roughly 1,000 nested calls (often a little before the exact limit). The setting is `sys.getrecursionlimit()` / `sys.setrecursionlimit()`. Increasing the limit only delays the failure; iterative insertion avoids recursion-depth failure.

## Part B — Rotations

**B3.** After `rotate_left(8)`, the root is 10; 8 becomes its left child; 14 remains the right child of 10; 3 (with children 1 and 6) remains the left child of 8. In-order traversal is **1, 3, 6, 8, 10, 14**. The subtree T2 becomes the right subtree of x; T1 remains left of x; T3 remains right of y. In this particular tree T2 is empty.

**B4.** A left rotation preserves the in-order sequence `T1, x, T2, y, T3`. All keys in T1 remain below x, keys in T2 remain between x and y, and keys in T3 remain above y, so the BST ordering is unchanged.

## Part C — AVL tree

**C6. AVL insertion trace.**

| Insert | First unbalanced node | BF there | Case | Rotation(s) |
|---:|---:|---:|---|---|
| 50 | — | — | — | none |
| 40 | — | — | — | none |
| 30 | 50 | +2 | LL | right rotate at 50 |
| 45 | — | — | — | none |
| 47 | 50 | +2 | LR | left rotate at 45, then right rotate at 50 |
| 20 | — | — | — | none |
| 10 | 30 | +2 | LL | right rotate at 30 |

Final AVL tree: `40(20(10,30),47(45,50))`, height **2 edges**. The plain BST for the same insertion sequence has height **4 edges**.

**C7.** A minimum-node AVL tree of height h must have one subtree of height h−1 and the other of height h−2 (otherwise it would not be minimally populated while satisfying the balance condition), plus the root. Therefore `N(h)=N(h−1)+N(h−2)+1`, with `N(0)=1`, `N(1)=2`.

| h | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| N(h) | 1 | 2 | 4 | 7 | 12 | 20 | 33 | 54 | 88 |

Continuing the recurrence gives N(27)=832,039 and N(28)=1,346,268. Therefore the largest possible height for an AVL tree containing 1,000,000 keys is **27 edges**.

## Part D — Red-Black trees

**D1. Figure classification.**

| Tree | Valid? | Reason |
|---:|---|---|
| 1 | Yes | Root black, no red-red edge, equal black-height on every root-to-NIL path. Black-height is 3 including NIL. |
| 2 | No | Red-red violation on edge 25–27. |
| 3 | No | Black-height mismatch: path through node 5 has one more black node than the path through node 30. |
| 4 | No | Root 7 is red; the root must be black. |

**D2. Insertions.**

| Insert | Fix-up case | Tree after fix-up (R = red, B = black; NIL leaves omitted) |
|---:|---|---|
| 41 | Root becomes black | `41B` |
| 38 | Parent black; no fix | `41B(38R, ∅)` |
| 31 | Case 3: black uncle, line; right-rotate at 41 | `38B(31R,41R)` |
| 12 | Case 1: red uncle; recolour 31 and 41 black, 38 red then root black | `38B(31B(12R,∅),41B)` |
| 19 | Case 2 triangle at 12, then Case 3 line at 31 | `38B(19B(12R,31R),41B)` |
| 8 | Case 1: red uncle (31); recolour 12 and 31 black, 19 red | `38B(19R(12B(8R,∅),31B),41B)` |

## Part E — Benchmarking

Measured locally using Python 3, one run, 1,000 searches per configuration. Timings vary by machine and run; height is deterministic for a given insertion order.

| n=8,000 | Input | Insert (ms) | 1,000 searches (ms) | Height (edges) |
|---|---|---:|---:|---:|
| BST | Random | 9.12 | 1.10 | 28 |
| AVL | Random | 44.04 | 0.82 | 15 |
| Red-Black | Random | 11.78 | 1.17 | 15 |
| Sorted list + bisect | Random | 5.33 | 0.41 | n/a |
| BST | Sorted | 1,947.62 | 242.28 | 7,999 |
| AVL | Sorted | 39.39 | 1.10 | 12 |
| Red-Black | Sorted | 22.08 | 1.22 | 22 |
| Sorted list + bisect | Sorted | 1.36 | 0.49 | n/a |

**E4(a).** On this run, the sorted-input BST took about 242.28 ms for 1,000 searches versus about 1.10 ms for AVL, approximately **220× slower**. The exact factor varies by run.

**E4(b).** Red-Black trees permit a looser balance than AVL trees, so they can be taller. Both keep height logarithmic in n, so the extra levels are small; Red-Black trees also typically need fewer rotations during insertion. Constant factors determine the observed search time.

**E4(c).** The sorted Python list wins this small benchmark because `bisect` search runs in optimized C over contiguous memory and has good cache locality. However, `insort` must shift elements in the list, making each insertion O(n) and building n elements O(n²) in the worst case. At 2,000,000 elements, insertion would become extremely expensive compared with balanced-tree insertion.

## Code and tests

Run `python week3_lab.py` and `python benchmark.py` in this folder. The implementation avoids external tree libraries. The two PNG plots and CSV measurements are included beside this sheet.
