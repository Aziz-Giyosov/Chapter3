import os, csv, random, time
import matplotlib.pyplot as plt
from week3_lab import BST, AVLTree, RBTree, SortedList
OUT=os.path.dirname(__file__)
rng=random.Random(2026); rows=[]
for n in (1000,2000,4000,8000):
  for order in ('random','sorted'):
    keys=list(range(n))
    if order=='random':rng.shuffle(keys)
    probe=rng.sample(keys,min(1000,n))
    for name,cls in [('BST',BST),('AVL',AVLTree),('Red-Black',RBTree),('Sorted list',SortedList)]:
      obj=cls(); start=time.perf_counter()
      for k in keys:obj.insert(k)
      insert_ms=(time.perf_counter()-start)*1000
      start=time.perf_counter()
      for k in probe:obj.search(k)
      search_ms=(time.perf_counter()-start)*1000
      rows.append({'n':n,'order':order,'structure':name,'insert_ms':insert_ms,'search_1000_ms':search_ms,'height_edges':obj.height()})
with open(os.path.join(OUT,'week3_benchmark.csv'),'w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
# Plot 1: height against n for random input, plus the requested log2(n) reference.
fig,ax=plt.subplots(figsize=(9,5))
ns=[1000,2000,4000,8000]
for name in ('BST','AVL','Red-Black'):
 vals=[next(x['height_edges'] for x in rows if x['n']==n and x['order']=='random' and x['structure']==name) for n in ns]
 ax.plot(ns,vals,marker='o',label=name)
ax.plot(ns,[__import__('math').log2(n) for n in ns],linestyle='--',label='log2(n) reference')
ax.set_xlabel('Number of keys (n)');ax.set_ylabel('Height (edges)');ax.set_title('Week 3: Height vs n (random input)');ax.legend();fig.tight_layout();fig.savefig(os.path.join(OUT,'week3_plot1_height_random.png'),dpi=160);plt.close(fig)
# Plot 2: height against n for sorted input, with logarithmic y-axis.
fig,ax=plt.subplots(figsize=(9,5))
for name in ('BST','AVL','Red-Black'):
 vals=[max(1,next(x['height_edges'] for x in rows if x['n']==n and x['order']=='sorted' and x['structure']==name)) for n in ns]
 ax.plot(ns,vals,marker='o',label=name)
ax.set_xlabel('Number of keys (n)');ax.set_ylabel('Height (edges; log scale)');ax.set_yscale('log');ax.set_title('Week 3: Height vs n (sorted input)');ax.legend();fig.tight_layout();fig.savefig(os.path.join(OUT,'week3_plot2_height_sorted.png'),dpi=160);plt.close(fig)
print('Wrote week3_benchmark.csv and two PNG plots')
for r in rows:
 if r['n']==8000: print(r)
