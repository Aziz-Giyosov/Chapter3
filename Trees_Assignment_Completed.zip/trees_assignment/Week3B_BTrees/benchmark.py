import os,csv,random,time,math
import matplotlib.pyplot as plt
from lab3b import BTree
OUT=os.path.dirname(__file__); rng=random.Random(2026); n=100_000
keys=rng.sample(range(10_000_000),n); probes=rng.sample(keys,5000); rows=[]
for t in (2,4,16,64,256):
 b=BTree(t);start=time.perf_counter()
 for k in keys:b.insert(k)
 build=time.perf_counter()-start;b.reads=0;start=time.perf_counter()
 for k in probes:b.search(k)
 search=(time.perf_counter()-start)/len(probes)*1e6;reads=b.reads/len(probes)
 rows.append({'structure':f'B-tree t={t}','build_s':build,'search_us':search,'reads_per_search':reads,'height':b.height(),'nodes':b.node_count(),'fill_factor':b.fill_factor()})
 print(rows[-1])
# Sorted list + bisect, as requested (insertion itself is O(n) per operation in the middle).
sorted_items=[];start=time.perf_counter()
for k in keys: __import__('bisect').insort(sorted_items,k)
build=time.perf_counter()-start;start=time.perf_counter()
for k in probes:
 i=__import__('bisect').bisect_left(sorted_items,k)
 if i==len(sorted_items) or sorted_items[i]!=k:raise AssertionError('probe missing')
search=(time.perf_counter()-start)/len(probes)*1e6
rows.append({'structure':'Sorted list + bisect','build_s':build,'search_us':search,'reads_per_search':'n/a','height':'n/a','nodes':'n/a','fill_factor':'n/a'})
with open(os.path.join(OUT,'lab3b_benchmark.csv'),'w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
# Plot 1: measured search time
fig,ax=plt.subplots(figsize=(9,5));ax.bar([r['structure'] for r in rows],[r['search_us'] for r in rows]);ax.set_ylabel('Average search time (microseconds)');ax.set_title('Week 3B: Search time, n = 100,000');ax.tick_params(axis='x',rotation=20);fig.tight_layout();fig.savefig(os.path.join(OUT,'lab3b_plot1_search_time.png'),dpi=160);plt.close(fig)
# Plot 2: page reads for B-trees
bt=[r for r in rows if str(r['reads_per_search'])!='n/a'];fig,ax=plt.subplots(figsize=(9,5));ax.bar([r['structure'] for r in bt],[r['reads_per_search'] for r in bt]);ax.set_ylabel('Average node/page reads per search');ax.set_title('Week 3B: B-tree page reads by minimum degree');fig.tight_layout();fig.savefig(os.path.join(OUT,'lab3b_plot2_page_reads.png'),dpi=160);plt.close(fig)
print('Wrote lab3b_benchmark.csv and two PNG plots')
