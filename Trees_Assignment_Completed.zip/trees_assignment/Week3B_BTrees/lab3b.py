"""Week 3B Lab - B-Trees. Recreated from the supplied handout's Appendix A."""
import bisect, random, time, csv, os
class BNode:
    __slots__=('keys','children','leaf')
    def __init__(self,leaf=True): self.keys=[]; self.children=[]; self.leaf=leaf
class BTree:
    def __init__(self,t=2):
        if t<2: raise ValueError('minimum degree t must be at least 2')
        self.t=t; self.root=BNode(True); self.reads=0; self.writes=0; self.splits=0; self.merges=0
    def search(self,key):
        node=self.root
        while True:
            self.reads+=1; i=bisect.bisect_left(node.keys,key)
            if i<len(node.keys) and node.keys[i]==key:return True
            if node.leaf:return False
            node=node.children[i]
    def insert(self,key):
        if self.search_existing_no_count(key): return
        root=self.root
        if len(root.keys)==2*self.t-1:
            new=BNode(False); new.children=[root]; self.root=new; self._split_child(new,0); self._insert_nonfull(new,key)
        else:self._insert_nonfull(root,key)
    def search_existing_no_count(self,key):
        n=self.root
        while True:
            i=bisect.bisect_left(n.keys,key)
            if i<len(n.keys) and n.keys[i]==key:return True
            if n.leaf:return False
            n=n.children[i]
    def _split_child(self,parent,i):
        t=self.t; y=parent.children[i]
        z=BNode(y.leaf); median=y.keys[t-1]
        z.keys=y.keys[t:]; y.keys=y.keys[:t-1]
        if not y.leaf: z.children=y.children[t:]; y.children=y.children[:t]
        parent.keys.insert(i,median); parent.children.insert(i+1,z)
        self.splits+=1; self.writes+=3
    def _insert_nonfull(self,node,key):
        i=bisect.bisect_left(node.keys,key)
        if node.leaf: node.keys.insert(i,key); self.writes+=1; return
        if len(node.children[i].keys)==2*self.t-1:
            self._split_child(node,i)
            if key>node.keys[i]:i+=1
            elif key==node.keys[i]:return
        self._insert_nonfull(node.children[i],key)
    def delete(self,key):
        self._delete(self.root,key)
        if not self.root.keys and not self.root.leaf:self.root=self.root.children[0]
    def _delete(self,node,key):
        t=self.t; self.reads+=1; i=bisect.bisect_left(node.keys,key)
        found=i<len(node.keys) and node.keys[i]==key
        if node.leaf: # Case 1: remove the key directly from a leaf if present.
            if found: node.keys.pop(i); self.writes+=1
            return
        if found:
            left,right=node.children[i],node.children[i+1]
            if len(left.keys)>=t: # Case 2a: replace with predecessor from a sufficiently large left child.
                pred=self._max_key(left); node.keys[i]=pred; self._delete(left,pred)
            elif len(right.keys)>=t: # Case 2b: replace with successor from a sufficiently large right child.
                succ=self._min_key(right); node.keys[i]=succ; self._delete(right,succ)
            else: # Case 2c: merge both minimum-size children with the separator, then delete in merged node.
                self._merge(node,i); self._delete(left,key)
            return
        child=node.children[i] # Case 3: key is not here; ensure target child has at least t keys before descending.
        if len(child.keys)==t-1:i=self._fill(node,i)
        self._delete(node.children[i],key)
    def _max_key(self,node):
        while not node.leaf:self.reads+=1; node=node.children[-1]
        return node.keys[-1]
    def _min_key(self,node):
        while not node.leaf:self.reads+=1; node=node.children[0]
        return node.keys[0]
    def _fill(self,node,i):
        t=self.t
        if i>0 and len(node.children[i-1].keys)>=t: # Case 3a: borrow from left sibling through parent separator.
            child,sib=node.children[i],node.children[i-1]; child.keys.insert(0,node.keys[i-1]); node.keys[i-1]=sib.keys.pop()
            if not sib.leaf:child.children.insert(0,sib.children.pop())
            self.writes+=3; return i
        if i<len(node.children)-1 and len(node.children[i+1].keys)>=t: # Case 3a: borrow from right sibling through parent separator.
            child,sib=node.children[i],node.children[i+1]; child.keys.append(node.keys[i]); node.keys[i]=sib.keys.pop(0)
            if not sib.leaf:child.children.append(sib.children.pop(0))
            self.writes+=3; return i
        if i<len(node.children)-1: # Case 3b: merge child with right sibling and separator before descent.
            self._merge(node,i); return i
        self._merge(node,i-1) # Case 3b: last child merges with its left sibling and separator.
        return i-1
    def _merge(self,node,i):
        left,right=node.children[i],node.children[i+1]; left.keys.append(node.keys.pop(i)); left.keys.extend(right.keys); left.children.extend(right.children); node.children.pop(i+1); self.merges+=1; self.writes+=2
    def range(self,lo,hi):
        out=[]
        def visit(node):
            self.reads+=1
            for i,k in enumerate(node.keys):
                # Child i contains values between the previous separator and k.
                previous=node.keys[i-1] if i>0 else None
                if not node.leaf and k>lo and (previous is None or previous<hi):
                    visit(node.children[i])
                if k>hi:return
                if k>=lo:out.append(k)
            if not node.leaf and (not node.keys or node.keys[-1]<hi):visit(node.children[-1])
        if lo<=hi:visit(self.root)
        return out
    def inorder(self):
        out=[]
        def go(n):
            for j,k in enumerate(n.keys):
                if not n.leaf:go(n.children[j])
                out.append(k)
            if not n.leaf:go(n.children[-1])
        go(self.root); return out
    def height(self):
        h,n=0,self.root
        while not n.leaf:n=n.children[0];h+=1
        return h
    def node_count(self):
        def go(n):return 1+sum(go(c) for c in n.children)
        return go(self.root)
    def fill_factor(self):
        nodes=keys=0; stack=[self.root]
        while stack:
            n=stack.pop();nodes+=1;keys+=len(n.keys);stack.extend(n.children)
        return keys/(nodes*(2*self.t-1))
    def to_tuple(self,node=None):
        node=self.root if node is None else node
        return (tuple(node.keys),tuple(self.to_tuple(c) for c in node.children))
    def is_valid(self):
        t=self.t; leaf_depths=[]
        def check(n,lo,hi,root=False,depth=0):
            k=len(n.keys)
            assert n.keys==sorted(n.keys),f'keys not sorted: {n.keys}'
            assert len(set(n.keys))==k,'duplicate key in node'
            assert k<=2*t-1,'node exceeds maximum keys'
            if not root: assert k>=t-1,f'non-root node underfull: {n.keys}'
            if root and not n.leaf: assert k>=1,'internal root is empty'
            for x in n.keys: assert (lo is None or x>lo) and (hi is None or x<hi),f'key {x} violates separator bounds'
            if n.leaf:
                assert len(n.children)==0,'leaf has children'; leaf_depths.append(depth); return
            assert len(n.children)==k+1,f'internal node with {k} keys must have {k+1} children'
            bounds=[lo]+n.keys+[hi]
            for j,c in enumerate(n.children):check(c,bounds[j],bounds[j+1],False,depth+1)
        check(self.root,None,None,True,0)
        assert len(set(leaf_depths))<=1,'leaves are at different depths'
        return True

def run_tests():
    b=BTree(2); b.root=BNode(False); b.root.keys=[20]; l,r=BNode(),BNode();l.keys=[5,10];r.keys=[30,40,50];b.root.children=[l,r]
    assert b.search(40) and not b.search(35);b.reads=0;b.search(50);assert b.reads==2;assert b.range(8,40)==[10,20,30,40]
    b=BTree(3);p,c=BNode(False),BNode();p.keys=[100];c.keys=[10,20,30,40,50];p.children=[c,BNode()];p.children[1].keys=[110,120];b._split_child(p,0);assert p.keys==[30,100] and [x.keys for x in p.children]==[[10,20],[40,50],[110,120]]
    rng=random.Random(7)
    for t in (2,3,5):
        b=BTree(t);keys=rng.sample(range(10000),3000)
        for k in keys:b.insert(k)
        assert b.is_valid() and b.inorder()==sorted(keys)
    b=BTree(2)
    for k in range(1,8):b.insert(k)
    assert b.to_tuple()==((2,4),(((1,),()),((3,),()),((5,6,7),())))
    b=BTree(2)
    for k in range(20):b.insert(k)
    b.root.children[0].keys.append(999)
    try:b.is_valid();raise AssertionError('validator accepted invalid tree')
    except AssertionError as e:
        if 'accepted invalid' in str(e):raise
    rng=random.Random(3);b=BTree(3);ref=set()
    for _ in range(4000):
        k=rng.randrange(800)
        if rng.random()<.55:b.insert(k);ref.add(k)
        else:b.delete(k);ref.discard(k)
        assert b.is_valid()
    assert b.inorder()==sorted(ref)
    print('PASS search, read counter and range')
    print('PASS split_child')
    print('PASS insert and validator (t = 2, 3, 5)')
    print('PASS validator detects broken tree')
    print('PASS deletion cases and invariants')

if __name__=='__main__':run_tests()
