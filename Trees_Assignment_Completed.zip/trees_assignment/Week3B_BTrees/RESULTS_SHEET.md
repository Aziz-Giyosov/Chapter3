# Week 3B — Lab 3B: B-Trees
**Name:** Aziz Giyosov  
**Student ID:** 4251456  
**Date:** 10 October 2026

## Part A — Cost model

### A1. Height bound and maximum keys per node
Use maximum keys per node = 2t−1 and the handout bound `h ≤ log_t((n+1)/2)`. Since height is an integer, take the floor of the bound.

| t | Max keys/node | Max height, n=5,000,000 | Max height, n=2,000,000,000 | Worst-case reads for larger n (h+1) |
|---:|---:|---:|---:|---:|
| 3 | 5 | 13 | 18 | 19 |
| 50 | 99 | 3 | 5 | 6 |
| 200 | 399 | 2 | 3 | 4 |
| 500 | 999 | 2 | 3 | 4 |

### A2. Page layout (4,096 bytes)
The node uses a 16-byte header, `2t−1` keys, and `2t` child pointers of 8 bytes each.

**(a) 8-byte integer keys:**
`16 + 8(2t−1) + 8(2t) ≤ 4096` → `32t + 8 ≤ 4096` → `t ≤ 127.75`. Largest integer t is **127**.

**(b) 24-byte string keys:**
`16 + 24(2t−1) + 8(2t) ≤ 4096` → `64t − 8 ≤ 4096` → `t ≤ 64.125`. Largest integer t is **64**.

### A3. One million keys
For the Red-Black tree of height 23: worst case reads = 23+1 = **24**. HDD time = 24×10 ms = **240 ms**; SSD time = 24×0.1 ms = **2.4 ms**.

For the B-tree with t=127, the handout bound gives `h ≤ floor(log_127((1,000,001)/2)) = 2`; worst case reads = **3**. HDD time = **30 ms**; SSD time = **0.3 ms**. If the root page is cached, subtract one page read: Red-Black **23 reads** (230 ms HDD, 2.3 ms SSD); B-tree **2 reads** (20 ms HDD, 0.2 ms SSD).

## Part B — Search and range query

**B3.** After the C1 insertion sequence, search for 18 visits `[15] → [25] → [18 20]`, for **3 reads**. Search for 13 visits `[15] → [8] → [12]`, for **3 reads** (13 is not found).

## Part C — Insertion, t=2

| Insert | Split? | Height after insertion | Tree in bracket form |
|---:|---|---:|---|
| 8 | No | 0 | `[8]` |
| 3 | No | 0 | `[3 8]` |
| 15 | No | 0 | `[3 8 15]` |
| 20 | Yes, root split | 1 | `[8]([3], [15 20])` |
| 1 | No | 1 | `[8]([1 3], [15 20])` |
| 12 | No | 1 | `[8]([1 3], [12 15 20])` |
| 25 | Yes, child split | 1 | `[8 15]([1 3], [12], [20 25])` |
| 30 | No | 1 | `[8 15]([1 3], [12], [20 25 30])` |
| 18 | Yes, child split | 1 | `[8 15 25]([1 3], [12], [18 20], [30])` |
| 5 | Yes, root split | 2 | `[15]([8]([1 3 5], [12]), [25]([18 20], [30]))` |

**C5.** Before descending, insertion splits any full child, and it only descends from a non-full parent. Thus the parent always has room to accept the promoted median; if the root is full, a new root is created first, so a split never needs to propagate back upward.

## Part D — Deletion trace (t=3)
Starting tree: `[30 60 90 120]([10 20], [40 50], [70 80], [100 110], [130 140 150])`.

| Delete | Cases applied | Tree afterwards |
|---:|---|---|
| 50 | Case 1 (delete from leaf) | `[30 90 120]([10 20], [40 60 70 80], [100 110], [130 140 150])` |
| 130 | Case 1 (delete from leaf) | `[30 90 120]([10 20], [40 60 70 80], [100 110], [140 150])` |
| 30 | Case 2b (replace by successor 40), then Case 1 | `[40 90 120]([10 20], [60 70 80], [100 110], [140 150])` |
| 110 | Case 3a (borrow from left sibling), then Case 1 | `[40 80 120]([10 20], [60 70], [90 100], [140 150])` |
| 140 | Case 3b (merge with left sibling and separator 120), then Case 1 | `[40 80]([10 20], [60 70], [90 100 120 150])` |

The code annotates the supplied deletion branches with their case labels and validates the tree after randomized insertions/deletions.

## Part E — Benchmarking, n=100,000

Measured locally with 100,000 distinct random keys and 5,000 successful searches. Timings vary by machine and run.

| Structure | Build (s) | Search (µs) | Avg. node/page reads | Height | Nodes | Fill factor |
|---|---:|---:|---:|---:|---:|---:|
| B-tree t=2 | 0.697 | 4.212 | 12.416 | 12 | 56,999 | 0.585 |
| B-tree t=4 | 0.481 | 2.309 | 6.773 | 6 | 21,703 | 0.658 |
| B-tree t=16 | 0.219 | 1.239 | 3.954 | 3 | 4,692 | 0.688 |
| B-tree t=64 | 0.178 | 1.434 | 2.989 | 2 | 1,149 | 0.685 |
| B-tree t=256 | 0.162 | 0.986 | 1.997 | 1 | 257 | 0.761 |
| Sorted list + bisect | 0.645 | 0.963 | n/a | n/a | n/a | n/a |

**E4(a).** Average reads can be slightly below height+1 because a search may find its key in an internal node before reaching a leaf.

**E4(b).** A B-tree with t=2 can be shorter than a Red-Black tree because each B-tree node can have multiple keys and up to four children, rather than a binary tree's two children. Its nodes therefore cover more keys per level.

**E4(c).** Larger t reduces the number of node visits. In Python, `bisect` searches within each node efficiently, so the reduced pointer traversal often outweighs the slightly larger in-node search.

**E4(d).** At 10 ms per page read, the measured average is about **124.16 ms** for t=2 and **19.97 ms** for t=256. These are cost-model estimates, not measured disk I/O timings.

## Code and tests

Run `python lab3b.py` and `python benchmark.py` in this folder. The code, CSV measurements, and two PNG plots are included beside this sheet.
