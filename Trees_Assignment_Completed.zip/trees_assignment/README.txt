ADVANCED TREES + B-TREES ASSIGNMENT PACKAGE

Contents
- Week3_Advanced_Trees/: completed Week 3 implementation, benchmark script, measured CSV, two plots, typed results sheet (PDF and Markdown).
- Week3B_BTrees/: completed Week 3B implementation, benchmark script, measured CSV, two plots, typed results sheet (PDF and Markdown).
- Reference_Handouts/: copies of the two supplied professor handouts.

Requirements: Python 3.10+ and matplotlib.
Install plotting dependency with: python -m pip install matplotlib

Run Week 3 tests:
  cd Week3_Advanced_Trees
  python week3_lab.py
  python benchmark.py

Run Week 3B tests:
  cd Week3B_BTrees
  python lab3b.py
  python benchmark.py

The test scripts were run successfully in the preparation environment. Benchmark timings are environment-specific and will vary if you rerun them. The CSV files and result-sheet tables preserve the measurements from the recorded run.

Note: The professor's separate starter .py files and rbtree.py were not among the uploaded files, so the programs were recreated from the starter-code appendices included in the two handouts. The optional +10-mark bonus challenges are not included in this core submission package. Review the results and code before submission, and follow your professor's academic-integrity rules.
